const extensionAPI = globalThis.browser || globalThis.chrome;
// Applies a theme after the page begins initializing, to avoid document_start conflicts.
const DEFAULTS = {
  globalMode: "dark",
  activePreset: "oled",
  siteRules: {},
  customCss: ""
};

const PRESETS = {
  oled:     { bg: "#000000", light: false },
  dark:     { bg: "#181818", light: false },
  nord:     { bg: "#2e3440", light: false },
  warm:     { bg: "#1f1b18", light: false },
  paper:    { bg: "#fbf0d9", light: true },
  softlight:{ bg: "#e8e8e8", light: true }
};
const STYLE_ID = "fluent-dark-reader-theme-v220";

function normalizeDomain(host) {
  return String(host || "").toLowerCase().replace(/^www\./, "").replace(/\.$/, "");
}
function findSiteRule(host, siteRules) {
  const normalizedHost = normalizeDomain(host);
  const matches = Object.keys(siteRules || {})
    .filter(key => {
      const domain = normalizeDomain(key);
      return normalizedHost === domain || normalizedHost.endsWith("." + domain);
    })
    .sort((a, b) => normalizeDomain(b).length - normalizeDomain(a).length);
  return matches.length ? siteRules[matches[0]] : null;
}
function makeCSS(settings) {
  const rule = findSiteRule(location.hostname, settings.siteRules);
  const mode = rule?.mode || settings.globalMode || "dark";
  if (mode === "disabled") return "";

  let presetKey = rule?.preset || settings.activePreset || (mode === "light" ? "paper" : "oled");
  if (!PRESETS[presetKey]) presetKey = mode === "light" ? "paper" : "oled";
  if (mode === "light" && !PRESETS[presetKey].light) presetKey = "paper";
  if (mode === "dark" && PRESETS[presetKey].light) presetKey = "oled";

  const preset = PRESETS[presetKey];
  // Requested rule: black text in Light mode; white text in Dark mode.
  const text = mode === "light" ? "#000000" : "#ffffff";
  const border = preset.light ? "rgba(0,0,0,.18)" : "rgba(255,255,255,.18)";

  return `
    html, body {
      background-color: ${preset.bg} !important;
      color: ${text} !important;
    }
    body, body *:not(img):not(video):not(iframe):not(canvas):not(svg):not(picture):not(source) {
      color: ${text} !important;
      border-color: ${border} !important;
    }
    body *:not(img):not(video):not(iframe):not(canvas):not(svg):not(picture):not(source):not(input):not(textarea):not(select):not(button):not(option) {
      background-color: transparent !important;
    }
    input, textarea, select, button, option {
      background-color: ${preset.bg} !important;
      color: ${text} !important;
      border-color: ${border} !important;
    }
    img, video, iframe, canvas, svg, picture {
      filter: ${preset.light ? "none" : "brightness(.96) contrast(1.02)"} !important;
    }
    ${settings.customCss || ""}
  `;
}

function applyTheme(settings) {
  if (!document.documentElement) return;
  let style = document.getElementById(STYLE_ID);
  const css = makeCSS({ ...DEFAULTS, ...settings });
  if (!css.trim()) {
    if (style) style.remove();
    return;
  }
  if (!style) {
    style = document.createElement("style");
    style.id = STYLE_ID;
    (document.head || document.documentElement).appendChild(style);
  }
  style.textContent = css;
}

async function loadAndApply() {
  try {
    const result = await extensionAPI.storage.local.get("settings");
    applyTheme({ ...DEFAULTS, ...(result.settings || {}) });
  } catch (error) {
    console.warn("Fluent Shade could not load settings:", error);
  }
}
extensionAPI.runtime.onMessage.addListener(message => {
  if (message?.action === "APPLY_SETTINGS" && message.settings) {
    applyTheme(message.settings);
  }
});
loadAndApply();

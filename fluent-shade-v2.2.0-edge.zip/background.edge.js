// Fluent Shade 2.2.0 — Microsoft Edge Manifest V3 service worker
const DEFAULT_SETTINGS = {
  globalMode: "dark",
  activePreset: "oled",
  scheduleEnabled: false,
  scheduleStart: "19:00",
  scheduleEnd: "07:00",
  siteRules: {},
  customCss: ""
};

async function getSettings() {
  const result = await chrome.storage.local.get("settings");
  const old = result.settings || {};
  const settings = { ...DEFAULT_SETTINGS, ...old, siteRules: { ...(old.siteRules || {}) } };
  delete settings.siteRules["wikipedia.org"];
  delete settings.siteRules["youtube.com"];
  if (JSON.stringify(settings) !== JSON.stringify(old)) {
    await chrome.storage.local.set({ settings });
  }
  return settings;
}

async function refreshWebTabs(settings) {
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.map(async tab => {
    if (!tab.id || !/^https?:/i.test(tab.url || "")) return;
    try {
      await chrome.tabs.sendMessage(tab.id, { action: "APPLY_SETTINGS", settings });
    } catch (_) {
      // Restricted pages or tabs whose content script is not ready are skipped.
    }
  }));
}

chrome.runtime.onInstalled.addListener(() => {
  getSettings().catch(error => console.error("Fluent Shade initialization failed:", error));
});

// Use sendResponse + return true for asynchronous responses in the service worker.
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request?.action === "GET_SETTINGS") {
    getSettings().then(
      settings => sendResponse({ settings }),
      error => { console.error("Fluent Shade settings request failed:", error); sendResponse({ error: "Settings unavailable" }); }
    );
    return true;
  }
  if (request?.action === "SETTINGS_UPDATED") {
    getSettings().then(async settings => {
      await refreshWebTabs(settings);
      sendResponse({ status: "ok" });
    }).catch(error => {
      console.error("Fluent Shade settings refresh failed:", error);
      sendResponse({ error: "Settings refresh failed" });
    });
    return true;
  }
  return false;
});

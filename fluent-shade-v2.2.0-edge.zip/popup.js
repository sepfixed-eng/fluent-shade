const extensionAPI = globalThis.browser || globalThis.chrome;
const DEFAULTS = {
  globalMode: "dark",
  activePreset: "oled",
  scheduleEnabled: false,
  scheduleStart: "19:00",
  scheduleEnd: "07:00",
  siteRules: {},
  customCss: ""
};
const PRESETS = {
  oled: "dark", dark: "dark", nord: "dark", warm: "dark",
  paper: "light", softlight: "light"
};
const $ = id => document.getElementById(id);
let settings = { ...DEFAULTS, siteRules: {} };
let currentDomain = "";
let currentMode = "dark";
let currentPreset = "oled";
let saveQueue = Promise.resolve();

function normalizeDomain(host) {
  return String(host || "").toLowerCase().replace(/^www\./, "").replace(/\.$/, "");
}
function findRule(host) {
  const normalized = normalizeDomain(host);
  const keys = Object.keys(settings.siteRules || {}).filter(key => {
    const d = normalizeDomain(key);
    return normalized === d || normalized.endsWith("." + d);
  }).sort((a,b) => normalizeDomain(b).length - normalizeDomain(a).length);
  return keys[0] ? { key: keys[0], rule: settings.siteRules[keys[0]] } : null;
}
function effectiveForCurrentSite() {
  const found = findRule(currentDomain);
  return found ? {
    mode: found.rule.mode || settings.globalMode,
    preset: found.rule.preset || settings.activePreset,
    hasRule: true
  } : { mode: settings.globalMode, preset: settings.activePreset, hasRule: false };
}
async function saveSettings() {
  $("saveStatus").textContent = "Saving…";
  const snapshot = JSON.parse(JSON.stringify(settings));
  saveQueue = saveQueue.then(async () => {
    await extensionAPI.storage.local.set({ settings: snapshot });
    await extensionAPI.runtime.sendMessage({ action: "SETTINGS_UPDATED" });
    $("saveStatus").textContent = "Saved";
  }).catch(error => {
    console.error("Fluent Shade could not save settings:", error);
    $("saveStatus").textContent = "Save failed — check about:debugging";
  });
  return saveQueue;
}
function render() {
  const effective = effectiveForCurrentSite();
  currentMode = effective.mode;
  currentPreset = effective.preset;
  for (const mode of ["dark", "light", "disabled"]) {
    $("modeBtn" + mode[0].toUpperCase() + mode.slice(1)).classList.toggle("active", currentMode === mode);
    $("defaultMode" + mode[0].toUpperCase() + mode.slice(1)).classList.toggle("active", settings.globalMode === mode);
  }
  const isLight = currentMode === "light";
  $("darkPresetsContainer").classList.toggle("hidden", !isLight && currentMode !== "disabled" ? false : true);
  $("lightPresetsContainer").classList.toggle("hidden", !isLight);
  $("modeStatusBadge").textContent = currentMode === "disabled" ? "Off" : (isLight ? "Light · Black text" : "Dark · White text");
  $("engineStatusFooter").textContent = currentMode === "disabled" ? "Theme off for this site" : "Theme engine active";
  document.querySelectorAll(".preset-card").forEach(el => el.classList.toggle("active", el.id === "preset-" + currentPreset));
  $("resetSiteBtn").disabled = !effective.hasRule;
}
function switchTab(name) {
  ["Main", "Sites", "Settings"].forEach(n => {
    $("tab" + n).classList.toggle("hidden", n !== name);
    $("tab" + n + "Btn").classList.toggle("active", n === name);
  });
  if (name === "Sites") renderSiteRules();
}
function renderSiteRules() {
  const box = $("siteRulesList");
  box.replaceChildren();
  for (const [domain, rule] of Object.entries(settings.siteRules || {}).sort((a,b) => a[0].localeCompare(b[0]))) {
    const row = document.createElement("div");
    row.className = "rule-item";
    const label = document.createElement("span");
    label.textContent = `${domain} — ${rule.mode || "inherit"}${rule.preset ? " / " + rule.preset : ""}`;
    const remove = document.createElement("button");
    remove.textContent = "Remove";
    remove.addEventListener("click", async () => {
      delete settings.siteRules[domain];
      renderSiteRules();
      render();
      await saveSettings();
    });
    row.append(label, remove);
    box.append(row);
  }
  if (!box.children.length) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = "No site-specific rules yet. Choose a mode while viewing a website to create one.";
    box.append(p);
  }
}
function applyCurrentSiteMode(mode) {
  if (!currentDomain) return;
  const old = findRule(currentDomain);
  const preset = old?.rule?.preset || settings.activePreset;
  settings.siteRules[currentDomain] = { mode, preset };
  render();
  saveSettings();
}
function setCurrentPreset(preset) {
  if (!currentDomain) return;
  const mode = PRESETS[preset];
  settings.siteRules[currentDomain] = { mode, preset };
  render();
  saveSettings();
}
async function init() {
  try {
    const result = await extensionAPI.storage.local.get("settings");
    settings = { ...DEFAULTS, ...(result.settings || {}), siteRules: { ...(result.settings?.siteRules || {}) } };
    // Drop old built-in defaults; custom rules remain.
    delete settings.siteRules["wikipedia.org"];
    delete settings.siteRules["youtube.com"];
    await extensionAPI.storage.local.set({ settings });
  } catch (error) {
    console.error("Could not load settings:", error);
  }

  try {
    const [tab] = await extensionAPI.tabs.query({ active: true, currentWindow: true });
    if (tab?.url && /^https?:/i.test(tab.url)) currentDomain = normalizeDomain(new URL(tab.url).hostname);
    $("currentDomain").textContent = currentDomain || "This browser page cannot be themed";
  } catch (_) {
    $("currentDomain").textContent = "This browser page cannot be themed";
  }

  $("openOptionsBtn").addEventListener("click", () => extensionAPI.runtime.openOptionsPage());
  $("tabMainBtn").addEventListener("click", () => switchTab("Main"));
  $("tabSitesBtn").addEventListener("click", () => switchTab("Sites"));
  $("tabSettingsBtn").addEventListener("click", () => switchTab("Settings"));

  for (const [label, mode] of [["Dark","dark"],["Light","light"],["Disabled","disabled"]]) {
    $("modeBtn" + label).addEventListener("click", () => applyCurrentSiteMode(mode));
    $("defaultMode" + label).addEventListener("click", async () => {
      settings.globalMode = mode;
      if (mode === "light" && PRESETS[settings.activePreset] === "dark") settings.activePreset = "paper";
      if (mode === "dark" && PRESETS[settings.activePreset] === "light") settings.activePreset = "oled";
      render();
      await saveSettings();
    });
  }

  for (const preset of Object.keys(PRESETS)) {
    $("preset-" + preset).addEventListener("click", () => setCurrentPreset(preset));
  }
  $("resetSiteBtn").addEventListener("click", async () => {
    const found = findRule(currentDomain);
    if (found) delete settings.siteRules[found.key];
    render();
    await saveSettings();
  });
  $("setGlobalBtn").addEventListener("click", async () => {
    settings.globalMode = currentMode;
    settings.activePreset = currentPreset;
    render();
    await saveSettings();
  });

  render();
}
document.addEventListener("DOMContentLoaded", init);

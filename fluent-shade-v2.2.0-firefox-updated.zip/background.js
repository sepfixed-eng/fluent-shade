// Fluent Shade 2.2.0 — Firefox MV3 background
const DEFAULT_SETTINGS = {
  globalMode: "dark",
  activePreset: "oled",
  scheduleEnabled: false,
  scheduleStart: "19:00",
  scheduleEnd: "07:00",
  siteRules: {},
  customCss: ""
};

async function getSettings() {
  const result = await browser.storage.local.get("settings");
  const old = result.settings || {};
  const settings = { ...DEFAULT_SETTINGS, ...old, siteRules: { ...(old.siteRules || {}) } };

  // Remove the original built-in overrides. Only user-created rules remain.
  delete settings.siteRules["wikipedia.org"];
  delete settings.siteRules["youtube.com"];

  if (JSON.stringify(settings) !== JSON.stringify(old)) {
    await browser.storage.local.set({ settings });
  }
  return settings;
}

async function refreshWebTabs(settings) {
  const tabs = await browser.tabs.query({});
  await Promise.all(tabs.map(async tab => {
    if (!tab.id || !/^https?:/i.test(tab.url || "")) return;
    try {
      await browser.tabs.sendMessage(tab.id, { action: "APPLY_SETTINGS", settings });
    } catch (_) {
      // Restricted pages or tabs whose content script is not ready are skipped.
    }
  }));
}

browser.runtime.onInstalled.addListener(() => {
  getSettings().catch(error => console.error("Fluent Shade initialization failed:", error));
});

browser.runtime.onMessage.addListener((request) => {
  if (request?.action === "GET_SETTINGS") {
    return getSettings().then(settings => ({ settings }));
  }
  if (request?.action === "SETTINGS_UPDATED") {
    return getSettings().then(async settings => {
      await refreshWebTabs(settings);
      return { status: "ok" };
    });
  }
});

const DEFAULTS = { globalMode:"dark", activePreset:"oled", scheduleEnabled:false, scheduleStart:"19:00", scheduleEnd:"07:00", siteRules:{}, customCss:"" };
const $ = id => document.getElementById(id);
let settings = { ...DEFAULTS };
async function load() {
  const result = await browser.storage.local.get("settings");
  settings = { ...DEFAULTS, ...(result.settings || {}), siteRules: { ...(result.settings?.siteRules || {}) } };
  delete settings.siteRules["wikipedia.org"];
  delete settings.siteRules["youtube.com"];
  $("optionsDefaultMode").value = settings.globalMode;
  $("optionsScheduleToggle").checked = !!settings.scheduleEnabled;
  $("optionsScheduleStart").value = settings.scheduleStart;
  $("optionsScheduleEnd").value = settings.scheduleEnd;
  $("optionsCustomCss").value = settings.customCss || "";
}
async function save() {
  settings.globalMode = $("optionsDefaultMode").value;
  settings.scheduleEnabled = $("optionsScheduleToggle").checked;
  settings.scheduleStart = $("optionsScheduleStart").value || "19:00";
  settings.scheduleEnd = $("optionsScheduleEnd").value || "07:00";
  settings.customCss = $("optionsCustomCss").value;
  try {
    await browser.storage.local.set({ settings });
    await browser.runtime.sendMessage({ action: "SETTINGS_UPDATED" });
    $("optionsStatus").textContent = "Saved successfully.";
  } catch (error) {
    console.error("Settings save failed:", error);
    $("optionsStatus").textContent = "Save failed. Check the extension debugger.";
  }
}
document.addEventListener("DOMContentLoaded", () => {
  load().catch(error => { console.error(error); $("optionsStatus").textContent = "Could not load settings."; });
  $("saveOptionsBtn").addEventListener("click", save);
});

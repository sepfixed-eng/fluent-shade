Fluent Shade 2.2.0 — Firefox development build

PROJECT CREDIT
- Project name: Fluent Shade
- Credit: Brandy
- License: GNU General Public License version 3.0 only (GPL-3.0-only); see LICENSE.

LEGAL NOTICES
- The Legal Notices page is legal.html and is linked from the popup and settings page.
- The disclaimer states that the software is provided as-is, no maintenance or support is promised, and the project is independent of the original Dark Reader team and Mozilla/Firefox.
- Before publishing, confirm you have the rights or permission needed to distribute all code, icons, and other assets. Preserve any third-party copyright and license notices.
- The disclaimer is informational and is not a substitute for legal advice.

BEFORE INSTALLING
- The toolbar icon is configured to use icons/Icon 1.png. Ensure your actual 128x128 PNG is in that folder and the filename/capitalization matches the manifest.

INSTALL FOR TESTING
1. Extract this ZIP.
2. Open about:debugging#/runtime/this-firefox.
3. Remove any previous temporary copy and load this package's manifest.json.

NORMAL FIREFOX INSTALLATION
- Regular Firefox generally requires Mozilla-signed extensions. This development ZIP is not itself a Mozilla-signed XPI. Submit the package through Mozilla Add-ons for signing before distributing it for normal installation.

BEHAVIOR
- Theme tab mode buttons set a rule for the current website.
- “Use default mode for this site” removes that override.
- “Make this mode the default for all sites” changes the global fallback.
- Settings tab offers the global default mode and schedule controls.
- Website text is black in Light mode and white in Dark mode.
- Off removes the injected theme for that site.

KNOWN LIMITS
- Sites with content in cross-origin iframes or shadow DOM may require additional handling.
- Website updates can affect styling behavior.
- This package has not been tested inside the user's specific Firefox installation.
